curl -X POST https://llm-summarize-word-docs-ucinc65roa-uc.a.run.app/summarize_word_documents \
-H "Content-Type: application/json" \
-d '{
     "file_name":"future_of_ai.docx"
}'

curl -X POST https://llm-summarize-word-docs-ucinc65roa-uc.a.run.app/summarize_word_documents \
-H "Content-Type: application/json" \
-d '{
     "file_name":"diet-nutritions.docx"
}'